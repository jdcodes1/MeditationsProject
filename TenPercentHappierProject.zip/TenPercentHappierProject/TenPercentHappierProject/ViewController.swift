import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // Dictionary to hold a list of topics with uuid as key
    var list:Dictionary<String, Topic> = [:]
    
    // Array to hold only featured topics
    var topics:[Topic] = []
    
    // Init the tableView
    let tableView: UITableView = {
        let tv = UITableView.init(frame: CGRect.zero, style: .grouped)
        tv.backgroundColor = UIColor.white
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Unselect the selected cell
        if let selectedIndexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: selectedIndexPath, animated: animated)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.sectionHeaderHeight = 100
        self.tableView.clipsToBounds = true
        self.tableView.register(TableViewCell.self, forCellReuseIdentifier: "cellId")
        let navigationBar: UINavigationBar = UINavigationBar(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 44))
        view.addSubview(navigationBar)
        setupTableView()
        TopicsManager.getMeditations { (topics: [Topic]) in
            // Completion
            self.topics = topics
            tableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 100))
        let label = UILabel(frame: CGRect(x: 20, y: 20, width: tableView.frame.size.width, height: 100))
        label.text = "Topics"
        label.font = UIFont.boldSystemFont(ofSize: 40)
        label.textColor = UIColor.black
        view.addSubview(label)
        return view
    }
    
    func setupTableView() {
        // Setting up delegates/data sources, constraints for tableview
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(TableViewCell.self, forCellReuseIdentifier: "cellId")
        tableView.separatorStyle = .none
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
                                        tableView.topAnchor.constraint(equalTo: self.view.topAnchor),
                                        tableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor),
                                        tableView.rightAnchor.constraint(equalTo: self.view.rightAnchor),
                                        tableView.leftAnchor.constraint(equalTo: self.view.leftAnchor)])
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Number of cells is equal to featuredList length
        return topics.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Create the cell for each topic using JSON data
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellId", for: indexPath) as! TableViewCell
        
        // Get the correct topic
        let topic : Topic = topics[indexPath.row]
        
        // Make the colored vertical bar!
        let topicColor = UIColor(hex: topic.color!)
        let myView = UIView(frame: CGRect(x: 10, y: 10, width: 10, height: 90))
        myView.backgroundColor = topicColor
        myView.clipsToBounds = true
        cell.addSubview(myView)
        cell.accessoryType = .disclosureIndicator
        
        // Show the number of meditations for each topic and subtopic and adjust labels
        var meditationsCount = topic.meditations!.count
        
        if let subTopicCount = topic.subTopics?.count {
            meditationsCount += subTopicCount
        }
        
        cell.topicLabel.text = "\(topic.title)"
        cell.meditationsLabel.text = "\(meditationsCount) Meditations"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // The given height of each cell
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Allows the cell to be clickable and handles passing in data
        let meditationsViewController: MeditationsViewController = MeditationsViewController()
        meditationsViewController.selectedTopic = topics[indexPath.row]
        self.navigationController?.pushViewController(meditationsViewController, animated: true)
    }
}

// An extension to UIColor that allows us to create colors given hex strings:
extension UIColor {
    public convenience init?(hex: String) {
        let r, g, b, a: CGFloat
        
        if hex.hasPrefix("#") {
            let start = hex.index(hex.startIndex, offsetBy: 1)
            let hexColor = String(hex[start...])
            
            if hexColor.count == 6 {
                let scanner = Scanner(string: hexColor)
                var hexNumber: UInt64 = 0
                
                if scanner.scanHexInt64(&hexNumber) {
                    r = CGFloat((hexNumber & 0xff0000) >> 16) / 255
                    g = CGFloat((hexNumber & 0x00ff00) >> 8) / 255
                    b = CGFloat((hexNumber & 0x0000ff) >> 0) / 255
                    a = 1
                    
                    self.init(red: r, green: g, blue: b, alpha: a)
                    return
                }
            }
        }
        
        return nil
    }
}
