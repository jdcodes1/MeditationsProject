import Foundation

// Create a struct for each topic
class Topic: NSObject {
    var uuid: String
    var title: String
    var position: Int
    var parent_uuid: String?
    var meditations: [String]?
    var featured: Bool
    var color: String?
    var topicDescription: String?
    var descriptionShort: String?
    var imageURL: String?
    var thumbnailURL: String?
    var subTopics: [Topic]?
    
    init(topic: [String : Any]) {
        uuid = topic["uuid"] as? String ?? ""
        title = topic["title"] as? String ?? ""
        position = topic["position"] as? Int ?? -1
        parent_uuid = topic["parent_uuid"] as? String ?? ""
        meditations = topic["meditations"] as? [String] ?? []
        featured = topic["featured"] as? Bool ?? false
        color = topic["color"] as? String ?? ""
        topicDescription = topic["description"] as? String ?? ""
        descriptionShort = topic["description_short"] as? String ?? ""
        imageURL = topic["image_url"] as? String ?? ""
        thumbnailURL = topic["thumbnail_url"] as? String ?? ""
        subTopics = []
    }
    
    func setSubtopic(subTopics: [Topic]) {
        self.subTopics = subTopics
    }
}
/*
Parent |________________|
       |                |
       |                |
Direct meditations   Children
                        |
                        |
                    Meditations
*/
