import UIKit

class MeditationsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var selectedTopic = Topic(topic: [:])
        
    var selectedTopicMeditations:Array<Meditation> = []
    
    let tableView: UITableView = {
        let tv = UITableView.init(frame:CGRect.zero, style: .grouped)
        tv.backgroundColor = UIColor.white
        tv.translatesAutoresizingMaskIntoConstraints = false
        return tv
    }()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Unselect the selected cell
        if let selectedIndexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: selectedIndexPath, animated: animated)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.sectionHeaderHeight = 100
        self.tableView.clipsToBounds = true
        self.tableView.register(MeditationTableViewCell.self, forCellReuseIdentifier: "meditationCellId")
        setupTableView()
    }
    
    @objc func back() {
        self.dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50))
        let label = UILabel(frame: CGRect(x: 20, y: 20, width: tableView.frame.size.width, height: 50))
        if (section == 0) {
            label.text = selectedTopic.title
            label.font = UIFont.boldSystemFont(ofSize: 40)
            let descriptionLabel = UILabel(frame: CGRect(x: 20, y: 100, width: tableView.frame.size.width, height: 50))
            descriptionLabel.text = selectedTopic.topicDescription
            descriptionLabel.textColor = UIColor.black
            descriptionLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
            descriptionLabel.numberOfLines = 3
            view.addSubview(descriptionLabel)
        }
        else if (section == 1) {
            label.text = "Meditations"
            label.font = UIFont.boldSystemFont(ofSize: 30)
        }
        else {
            label.text = selectedTopic.subTopics?[section - 2].title
            label.font = UIFont.boldSystemFont(ofSize: 30)
        }
        label.textColor = UIColor.black
        view.addSubview(label)
        return view
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Header \(section)"
    }
    
    func setupTableView() {
        // Setting up delegates/data sources, constraints for tableview
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
                tableView.topAnchor.constraint(equalTo: self.view.topAnchor),
                tableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor),
                tableView.rightAnchor.constraint(equalTo: self.view.rightAnchor),
                tableView.leftAnchor.constraint(equalTo: self.view.leftAnchor)])
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (section == 0) {return 1}
        
        if let subTopicCount = selectedTopic.subTopics?.count {
            if (section <= subTopicCount) {
                guard let rows = selectedTopic.subTopics?[section - 1].meditations?.count else {
                    return 0
                }
                return rows
            }
        }
        
        if let meditationCount = selectedTopic.meditations?.count {
            return meditationCount
        }
        return 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        var count = 1
        if let subTopicCount = selectedTopic.subTopics?.count {
            count += subTopicCount
        }
        if selectedTopic.meditations != nil && selectedTopic.meditations!.count > 0 {
            count += 1
        }
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if (indexPath.section == 0) {
            return UITableViewCell()
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "meditationCellId", for: indexPath) as! MeditationTableViewCell

        var meditation: Meditation? = nil
        
        if let subTopicCount = selectedTopic.subTopics?.count {
            if (indexPath.section <= subTopicCount) {
                guard let _ = selectedTopic.subTopics?[indexPath.section - 1].meditations?.count else {
                    return cell
                }
                guard let uuid: String = selectedTopic.subTopics?[indexPath.section - 1].meditations?[indexPath.row] else {
                    return cell
                }
                meditation = TopicsManager.getMeditation(uuid: uuid)
            }
        }
        
        if let _ = selectedTopic.meditations?.count {
            if meditation == nil {
                guard let meditationUUID = selectedTopic.meditations?[indexPath.row] else {
                    return cell
                }
                meditation = TopicsManager.getMeditation(uuid: meditationUUID)
            }
        }
        
        guard let meditationUnwrapped = meditation else {
            return cell
        }
        
        cell.meditationLabel.text = "\(meditationUnwrapped.title)"
        cell.authorLabel.text = "\(meditationUnwrapped.teacher_name)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Clicked a meditation cell!")
    }
    
    @objc func backButtonClicked(sender: UIButton!) {
        performSegue(withIdentifier: "back", sender: self)
    }
}
