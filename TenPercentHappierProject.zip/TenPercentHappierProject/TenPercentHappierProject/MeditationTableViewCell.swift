import UIKit

class MeditationTableViewCell: UITableViewCell {

    let cellView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 3
        view.translatesAutoresizingMaskIntoConstraints = false
        view.clipsToBounds = false
        view.layer.masksToBounds = false
        view.layer.shadowColor = UIColor.gray.cgColor
        view.layer.shadowOpacity = 1
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 1
        return view
    }()
    
    let meditationLabel: UILabel = {
        let label = UILabel()
        label.text = "Meditation"
        label.textColor = UIColor.black
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    let authorLabel: UILabel = {
        let label = UILabel()
        label.text = "Author"
        label.textColor = UIColor.lightGray
        label.font = UIFont.systemFont(ofSize: 15)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }

    func setupView() {
        addSubview(cellView)
        cellView.addSubview(meditationLabel)
        cellView.addSubview(authorLabel)
        self.selectionStyle = .none
        NSLayoutConstraint.activate([
            cellView.topAnchor.constraint(equalTo: self.topAnchor, constant: 10),
            cellView.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -10),
            cellView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10),
            cellView.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            meditationLabel.heightAnchor.constraint(equalToConstant: 100),
            meditationLabel.widthAnchor.constraint(equalToConstant: 200),
            meditationLabel.centerYAnchor.constraint(equalTo: cellView.centerYAnchor, constant: -15),
            meditationLabel.leftAnchor.constraint(equalTo: cellView.leftAnchor, constant: 20),
            authorLabel.heightAnchor.constraint(equalToConstant: 100),
            authorLabel.widthAnchor.constraint(equalToConstant: 200),
            authorLabel.centerYAnchor.constraint(equalTo: cellView.centerYAnchor, constant: 10),
            authorLabel.leftAnchor.constraint(equalTo: cellView.leftAnchor, constant: 20),
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
