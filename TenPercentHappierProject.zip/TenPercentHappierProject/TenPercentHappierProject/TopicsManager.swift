import UIKit

class TopicsManager: NSObject {
    
    static func getMeditations(completion: ([Topic]) -> Void) {
        guard let path = Bundle.main.path(forResource: "topics", ofType: "json") else{
            completion([])
            return
        }
        do {
            // Grab the JSON data and format it into a dictionary
            let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
            guard let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves) as? [String : Any] else {
                completion([])
                return
            }
            guard let topics = jsonResult["topics"] as? [Any] else {
                completion([])
                return
            }
            var list:[Topic] = []
            var parentUUIDToChildren: [String : [Topic]] = [:]
            for t in topics {
                guard let tDict = t as? [String : Any] else {
                    continue
                }
                let myTopic: Topic = Topic(topic: tDict)
                
                if (myTopic.featured == true && myTopic.parent_uuid == "") {
                    list.append(myTopic)
                }
                if (myTopic.parent_uuid != nil) {
                    if parentUUIDToChildren[myTopic.parent_uuid!] == nil {
                        parentUUIDToChildren[myTopic.parent_uuid!] = []
                    }
                    parentUUIDToChildren[myTopic.parent_uuid!]!.append(myTopic)
                }
            }
            for topic in list {
                if let subTopics = parentUUIDToChildren[topic.uuid] {
                    topic.setSubtopic(subTopics: subTopics)
                }
            }
            completion(list)
        } catch {
            print(error.localizedDescription)
            completion([])
            return
        }
    }
    
    static func getMeditation(uuid: String) -> Meditation? {
        guard let path = Bundle.main.path(forResource: "meditations", ofType: "json") else {
            return nil
        }
        do {
            // Grab the JSON data and format it into a dictionary
            let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
            guard let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves) as? [String : Any] else {
                return nil
            }
            guard let meditations = jsonResult["meditations"] as? [Any] else {
                return nil
            }
            for m in meditations {
                guard let mMed = m as? [String : Any] else {
                    return nil
                }
                let meditation: Meditation = Meditation(meditation: mMed)
                if (meditation.uuid == uuid) {
                    return meditation
                }
            }
            return nil
        } catch {
            print(error.localizedDescription)
        }
        return nil
    }
}
