import Foundation

struct Meditation {
    var uuid: String
    var title: String
    var teacher_name: String
    var image_url: String
    var play_count: Int
    var background_image_url: String
    var description: String
    var position: Int
    
    init(meditation: [String : Any]) {
        uuid = meditation["uuid"] as? String ?? ""
        title = meditation["title"] as? String ?? ""
        teacher_name = meditation["teacher_name"] as? String ?? ""
        image_url = meditation["image_url"] as? String ?? ""
        play_count = meditation["play_count"] as? Int ?? 0
        background_image_url = meditation["background_image_url"] as? String ?? ""
        description = meditation["description"] as? String ?? ""
        position = meditation["position"] as? Int ?? -1
    }
}
