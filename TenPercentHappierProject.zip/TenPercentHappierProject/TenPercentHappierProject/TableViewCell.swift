import UIKit

class TableViewCell: UITableViewCell {
    
    // Create the cell view and make it "card" like
    let cellView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 3
        view.translatesAutoresizingMaskIntoConstraints = false
        view.clipsToBounds = false
        view.layer.masksToBounds = false
        view.layer.shadowColor = UIColor.gray.cgColor
        view.layer.shadowOpacity = 1
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 1
        return view
    }()
    
    // Label for the topic name
    let topicLabel: UILabel = {
        let label = UILabel()
        label.text = "Featured"
        label.textColor = UIColor.black
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    // Label for the number of meditations
    let meditationsLabel: UILabel = {
        let label = UILabel()
        label.text = "38 Meditations"
        label.textColor = UIColor.lightGray
        label.font = UIFont.systemFont(ofSize: 15)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }
    
    // Setup the constraints for labels and cell
    func setupView() {
        addSubview(cellView)
        cellView.addSubview(topicLabel)
        cellView.addSubview(meditationsLabel)
        self.selectionStyle = .none
        NSLayoutConstraint.activate([
                                        cellView.topAnchor.constraint(equalTo: self.topAnchor, constant: 10),
                                        cellView.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -10),
                                        cellView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10),
                                        cellView.bottomAnchor.constraint(equalTo: self.bottomAnchor),
                                        meditationsLabel.heightAnchor.constraint(equalToConstant: 100),
                                        meditationsLabel.widthAnchor.constraint(equalToConstant: 200),
                                        meditationsLabel.centerYAnchor.constraint(equalTo: cellView.centerYAnchor, constant: 10),
                                        meditationsLabel.leftAnchor.constraint(equalTo: cellView.leftAnchor, constant: 20),
                                        topicLabel.heightAnchor.constraint(equalToConstant: 200),
                                        topicLabel.widthAnchor.constraint(equalToConstant: 200),
                                        topicLabel.centerYAnchor.constraint(equalTo: cellView.centerYAnchor, constant: -10),
                                        topicLabel.leftAnchor.constraint(equalTo: cellView.leftAnchor, constant: 20)])
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
